---
Name: "H&K CAWS"
type: shotgun
Barrel Length:
Caliber: 12ga H&K
Cap.: 12
Dam.: 
Pen.: 12*
Rng: x3/x4*
ROF: CQB/T
Speed: S/B2
Rec: 3/5/7
Bulk: 10
Wgt: 3
volume:
Bulk (N):
BV: 3.6 kg
SP: N/A
Source: 
Notes:
tags:
  - smallArms
---
