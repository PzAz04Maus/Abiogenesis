---
Name: "NSV 12.7x108mm"
type: machinegun
Barrel Length:
Caliber: 50
Cap.: (bt)
Dam.: 16
Pen.: x1/x2
Rng: S/EX
ROF: B5/B10
Speed: 7/11/16
Rec: 18
Bulk: 7
Wgt: 25 kg
volume:
Bulk (N):
BV: GG2,700
SP: $10,800
Source: 
Notes:
tags:
  - smallArms
---
