---
Name: "Lee-Enfield No. 4 Mk. 1 .303 British"
type: rifle
Barrel Length:
Caliber: 10
Cap.: (in)
Dam.: 8
Pen.: x2/x3
Rng: M/EX
ROF: S
Speed: 5/8/11
Rec: 10
Bulk: 4
Wgt: 3.7 kg
volume:
Bulk (N):
BV: GG335
SP: $670
Source: 
Notes:
tags:
  - smallArms
---
