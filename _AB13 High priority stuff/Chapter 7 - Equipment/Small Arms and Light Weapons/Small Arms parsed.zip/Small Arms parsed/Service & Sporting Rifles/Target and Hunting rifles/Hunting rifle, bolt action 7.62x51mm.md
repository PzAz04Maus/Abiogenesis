---
Name: "Hunting rifle, bolt action 7.62x51mm"
type: rifle
Barrel Length:
Caliber: 5
Cap.: (in)
Dam.: 8
Pen.: x2/x3
Rng: M/EX
ROF: S
Speed: 5/8/11
Rec: 10
Bulk: 4
Wgt: 3.3 kg
volume:
Bulk (N):
BV: GG400
SP: $800
Source: 
Notes:
tags:
  - smallArms
---
