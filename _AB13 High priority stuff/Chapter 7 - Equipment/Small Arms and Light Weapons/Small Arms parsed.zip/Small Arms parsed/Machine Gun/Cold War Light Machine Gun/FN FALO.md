---
Name: "FN FALO"
type: machinegun
Barrel Length:
Caliber: 7.62x51mm
Cap.: 30
Dam.: 
Pen.: 8
Rng: x2/x3
ROF: M/S
Speed: S/B5
Rec: 4/6/9
Bulk: 7
Wgt: 4
volume:
Bulk (N):
BV: 6.0 kg
SP: GG1,000
Source: 
Notes:
tags:
  - smallArms
---
