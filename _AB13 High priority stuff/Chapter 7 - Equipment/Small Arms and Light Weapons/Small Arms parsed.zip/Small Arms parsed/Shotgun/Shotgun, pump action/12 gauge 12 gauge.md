---
Name: "12 gauge 12 gauge"
type: shotgun
Barrel Length:
Caliber: 7
Cap.: (in)
Dam.: 10
Pen.: x4/Nil
Rng: CQB/T
ROF: S
Speed: 5/8/11
Rec: 19
Bulk: 4
Wgt: 3.6 kg
volume:
Bulk (N):
BV: GG210
SP: $420
Source: 
Notes:
tags:
  - smallArms
---
