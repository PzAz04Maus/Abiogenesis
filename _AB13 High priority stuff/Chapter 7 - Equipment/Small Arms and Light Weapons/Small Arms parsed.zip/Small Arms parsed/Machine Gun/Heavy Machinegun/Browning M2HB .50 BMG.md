---
Name: "Browning M2HB .50 BMG"
type: machinegun
Barrel Length:
Caliber: 105
Cap.: (bt)
Dam.: 16
Pen.: x1/x2
Rng: S/EX
ROF: S/B4/B8
Speed: 7/11/16
Rec: 15
Bulk: 7
Wgt: 38 kg
volume:
Bulk (N):
BV: GG3,200
SP: $12,700
Source: 
Notes:
tags:
  - smallArms
---
