---
Name: "20 gauge 20 gauge"
type: shotgun
Barrel Length:
Caliber: 5
Cap.: (in)
Dam.: 9
Pen.: x4/Nil
Rng: CQB/T
ROF: S
Speed: 4/6/9
Rec: 11
Bulk: 4
Wgt: 3.5 kg
volume:
Bulk (N):
BV: GG150
SP: $600
Source: 
Notes:
tags:
  - smallArms
---
