---
Name: "Small game rifle, bolt action 5.56x45mm"
type: rifle
Barrel Length:
Caliber: 6
Cap.: (in)
Dam.: 6
Pen.: x2/x3
Rng: M/S
ROF: S
Speed: 5/8/11
Rec: 5
Bulk: 4
Wgt: 3.1 kg
volume:
Bulk (N):
BV: GG230
SP: $700
Source: 
Notes:
tags:
  - smallArms
---
