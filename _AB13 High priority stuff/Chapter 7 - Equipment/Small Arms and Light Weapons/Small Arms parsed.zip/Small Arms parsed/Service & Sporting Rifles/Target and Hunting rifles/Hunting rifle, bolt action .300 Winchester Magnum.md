---
Name: "Hunting rifle, bolt action .300 Winchester Magnum"
type: rifle
Barrel Length:
Caliber: 3
Cap.: (in)
Dam.: 10
Pen.: x1/x2
Rng: M/EX
ROF: S
Speed: 5/8/11
Rec: 13
Bulk: 4
Wgt: 3.4 kg
volume:
Bulk (N):
BV: GG425
SP: $850
Source: 
Notes:
tags:
  - smallArms
---
