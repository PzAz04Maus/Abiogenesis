---
Name: "10 gauge 10 gauge"
type: shotgun
Barrel Length:
Caliber: 4
Cap.: (in)
Dam.: 10
Pen.: x4/Nil
Rng: CQB/T
ROF: S
Speed: 5/8/11
Rec: 23
Bulk: 4
Wgt: 3.7 kg
volume:
Bulk (N):
BV: GG365
SP: $730
Source: 
Notes:
tags:
  - smallArms
---
