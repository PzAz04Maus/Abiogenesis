---
Name: "L1A1 SLR"
type: battleRifle
Barrel Length:
Caliber: 7.62x51mm
Cap.: 20
Dam.: 8
Pen.: x2/x3
Rng: M/S
ROF: S
Speed: 3/6/8
Rec: 9
Bulk: 3
Wgt: 4.3 kg
volume:
Bulk (N):
BV: GG700
SP: $1,400
Source: 
Notes:
tags:
  - smallArms
---
