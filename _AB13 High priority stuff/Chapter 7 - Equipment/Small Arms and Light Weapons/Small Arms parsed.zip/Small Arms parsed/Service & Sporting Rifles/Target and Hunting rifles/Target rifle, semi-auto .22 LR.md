---
Name: "Target rifle, semi-auto .22 LR"
type: rifle
Barrel Length:
Caliber: 10
Cap.: (in)
Dam.: 3
Pen.: x4/Nil
Rng: CQB/T
ROF: S
Speed: 3/4/6
Rec: 2
Bulk: 3
Wgt: 2.1 kg
volume:
Bulk (N):
BV: GG60
SP: $240
Source: 
Notes:
tags:
  - smallArms
---
