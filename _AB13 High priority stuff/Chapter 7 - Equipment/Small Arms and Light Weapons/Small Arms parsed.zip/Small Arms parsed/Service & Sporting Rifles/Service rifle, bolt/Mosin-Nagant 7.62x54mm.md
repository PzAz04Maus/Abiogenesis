---
Name: "Mosin-Nagant 7.62x54mm"
type: rifle
Barrel Length:
Caliber: 5
Cap.: (in)
Dam.: 8
Pen.: x2/x3
Rng: M/EX
ROF: S
Speed: 5/8/11
Rec: 9
Bulk: 4
Wgt: 4.1 kg
volume:
Bulk (N):
BV: GG100
SP: $200
Source: 
Notes:
tags:
  - smallArms
---
