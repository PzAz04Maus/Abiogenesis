---
Name: "AAI CAWS"
type: shotgun
Barrel Length:
Caliber: 12ga
Cap.: 10
Dam.: 
Pen.: 10
Rng: x4/Nil
ROF: CQB/T
Speed: S/B3
Rec: 3/5/8
Bulk: 14
Wgt: 3
volume:
Bulk (N):
BV: 4.1 kg
SP: N/A
Source: 
Notes:
tags:
  - smallArms
---
