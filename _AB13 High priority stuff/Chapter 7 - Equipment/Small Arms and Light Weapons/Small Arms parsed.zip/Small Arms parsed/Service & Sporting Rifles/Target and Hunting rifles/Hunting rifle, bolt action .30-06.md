---
Name: "Hunting rifle, bolt action .30-06"
type: rifle
Barrel Length:
Caliber: 4
Cap.: (in)
Dam.: 9
Pen.: x2/x3
Rng: M/EX
ROF: S
Speed: 5/8/11
Rec: 11
Bulk: 4
Wgt: 3.4 kg
volume:
Bulk (N):
BV: GG420
SP: $840
Source: 
Notes:
tags:
  - smallArms
---
