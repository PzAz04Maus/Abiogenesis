---
Name: "Bullup assault rifle"
type: assaultRifle
Barrel Length:
Caliber: 5.56x45mm
Cap.: 30
Dam.: 6
Pen.: x2/x3
Rng: M/S
ROF: S/B5
Speed: 3/4/6
Rec: 4
Bulk: 3
Wgt: 4.3 kg
volume:
Bulk (N):
BV: GG900
SP: $1,200
Source: 
Notes:
tags:
  - smallArms
---
