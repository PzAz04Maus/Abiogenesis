---
Name: "Target rifle, bolt action .22 LR"
type: rifle
Barrel Length:
Caliber: 5
Cap.: (in)
Dam.: 3
Pen.: x4/Nil
Rng: CQB/T
ROF: S
Speed: 4/6/9
Rec: 1
Bulk: 3
Wgt: 2.5 kg
volume:
Bulk (N):
BV: GG55
SP: $230
Source: 
Notes:
tags:
  - smallArms
---
