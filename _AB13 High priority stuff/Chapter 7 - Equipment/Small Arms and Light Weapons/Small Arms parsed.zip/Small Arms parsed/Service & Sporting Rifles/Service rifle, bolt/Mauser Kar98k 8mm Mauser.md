---
Name: "Mauser Kar98k 8mm Mauser"
type: rifle
Barrel Length:
Caliber: 5
Cap.: (in)
Dam.: 9
Pen.: x2/x3
Rng: M/EX
ROF: S
Speed: 5/8/11
Rec: 8
Bulk: 4
Wgt: 4.1 kg
volume:
Bulk (N):
BV: GG435
SP: $870
Source: 
Notes:
tags:
  - smallArms
---
