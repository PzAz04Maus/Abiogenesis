---
Name: "12 gauge 12 gauge"
type: shotgun
Barrel Length:
Caliber: 7
Cap.: (in)
Dam.: 10
Pen.: x4/Nil
Rng: CQB/T
ROF: S
Speed: 4/6/9
Rec: 16
Bulk: 4
Wgt: 3.8 kg
volume:
Bulk (N):
BV: GG180
SP: $680
Source: 
Notes:
tags:
  - smallArms
---
