---
Name: "Hunting rifle, bolt action 6.5x55mm"
type: rifle
Barrel Length:
Caliber: 5
Cap.: (in)
Dam.: 8
Pen.: x2/x3
Rng: M/EX
ROF: S
Speed: 5/8/11
Rec: 8
Bulk: 4
Wgt: 4 kg
volume:
Bulk (N):
BV: GG230
SP: $700
Source: 
Notes:
tags:
  - smallArms
---
