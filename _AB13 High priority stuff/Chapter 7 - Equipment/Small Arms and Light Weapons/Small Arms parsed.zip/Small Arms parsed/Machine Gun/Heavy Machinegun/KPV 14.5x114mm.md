---
Name: "KPV 14.5x114mm"
type: machinegun
Barrel Length:
Caliber: 100
Cap.: (bt)
Dam.: 21
Pen.: x1/x2
Rng: S/EX
ROF: S/B4/B7
Speed: 8/12/18
Rec: 19
Bulk: 8
Wgt: 49 kg
volume:
Bulk (N):
BV: GG4,200
SP: $16,600
Source: 
Notes:
tags:
  - smallArms
---
