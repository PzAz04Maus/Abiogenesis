---
Name: "Big game rifle, bolt-action .460 Weatherby Magnum"
type: rifle
Barrel Length:
Caliber: 2
Cap.: (in)
Dam.: 12
Pen.: x2/x3
Rng: M/EX
ROF: S
Speed: 6/9/14
Rec: 27
Bulk: 5
Wgt: 4.5 kg
volume:
Bulk (N):
BV: GG750
SP: $3,000
Source: 
Notes:
tags:
  - smallArms
---
