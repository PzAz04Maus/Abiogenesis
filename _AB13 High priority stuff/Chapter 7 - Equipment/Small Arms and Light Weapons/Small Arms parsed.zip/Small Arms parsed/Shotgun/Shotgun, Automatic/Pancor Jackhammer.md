---
Name: "Pancor Jackhammer"
type: shotgun
Barrel Length:
Caliber: 12ga
Cap.: 10
Dam.: 
Pen.: 10
Rng: x4/Nil
ROF: CQB/T
Speed: S/B2
Rec: 3/5/7
Bulk: 17
Wgt: 3
volume:
Bulk (N):
BV: 4.6 kg
SP: GG10,000
Source: 
Notes:
tags:
  - smallArms
---
