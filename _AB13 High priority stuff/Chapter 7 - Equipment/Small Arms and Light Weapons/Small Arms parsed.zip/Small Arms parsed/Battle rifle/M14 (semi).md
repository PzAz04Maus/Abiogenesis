---
Name: "M14 (semi)"
type: battleRifle
Barrel Length:
Caliber: 7.62x51mm
Cap.: 20
Dam.: 8
Pen.: x2/x3
Rng: M/EX
ROF: S
Speed: 4/6/9
Rec: 8
Bulk: 4
Wgt: 5.2 kg
volume:
Bulk (N):
BV: GG500
SP: $1,000
Source: 
Notes:
tags:
  - smallArms
---
