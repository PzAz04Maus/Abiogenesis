---
Name: "H&K G36K 5.56x45mm NATO"
type: assaultRifle
Barrel Length:
Caliber: 30 or
Cap.: 100
Dam.: 6
Pen.: x2/x3
Rng: T/Open
ROF: S/B2/B5
Speed: 3/4/6
Rec: 4
Bulk: 3
Wgt: 3.3kg
volume:
Bulk (N):
BV: GG600
SP: $1,200
Source: 
Notes:
tags:
  - smallArms
---
