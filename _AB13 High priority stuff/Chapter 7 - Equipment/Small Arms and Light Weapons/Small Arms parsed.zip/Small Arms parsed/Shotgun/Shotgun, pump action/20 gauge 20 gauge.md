---
Name: "20 gauge 20 gauge"
type: shotgun
Barrel Length:
Caliber: 4
Cap.: (in)
Dam.: 9
Pen.: x4/Nil
Rng: CQB/T
ROF: S
Speed: 5/8/11
Rec: 13
Bulk: 4
Wgt: 3.3 kg
volume:
Bulk (N):
BV: GG135
SP: $545
Source: 
Notes:
tags:
  - smallArms
---
